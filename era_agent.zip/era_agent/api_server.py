"""FastAPI server for Era Agent.

Exposes the existing local command agent over HTTP so a remote
assistant (Era, built in Google AI Studio) can trigger commands by
name. This file only adds a web layer on top of the existing command
registry -- none of the original command logic in
`commands/system_commands.py` or `commands/registry.py` is changed,
and the interactive CLI in `main.py` keeps working exactly as before.

Run with:
    uvicorn api_server:app --reload --port 8000

Then test it with a browser, curl, or Postman -- see README.md for
step-by-step instructions.
"""

from __future__ import annotations

from typing import Dict, List

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, field_validator
from starlette.concurrency import run_in_threadpool

from commands import registry
from commands.registry import CommandResult

# Commands that call Python's input() internally -- they were built
# for the interactive `era>` prompt in main.py (e.g. they ask for a
# file name, a contact, or a yes/no confirmation). Over HTTP there is
# no terminal for them to read from, so calling one here would hang
# the request. We don't touch or rewrite those commands; we just
# recognize them by name and return an immediate, clear explanation
# instead of executing them.
INTERACTIVE_COMMANDS = {
    "search_file",
    "open_whatsapp",
    "shutdown_pc",
    "restart_pc",
    "cancel_shutdown",
    "open_browser",
    "open_app",
}

app = FastAPI(
    title="Era Agent API",
    description="Local HTTP API that lets the Era assistant execute Era Agent commands.",
    version="1.0.0",
)

# Local-development CORS setup so a browser-based caller (e.g. a Google
# AI Studio app running in the browser) can reach this API. This
# server only runs on your own machine and only ever executes commands
# that are already registered by name -- if you expose it beyond
# localhost, tighten allow_origins to the exact origin(s) you trust.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


class ExecuteRequest(BaseModel):
    """Request body for POST /execute, e.g. {"command": "open_camera"}."""

    command: str

    @field_validator("command")
    @classmethod
    def command_must_not_be_blank(cls, value: str) -> str:
        cleaned = value.strip()
        if not cleaned:
            raise ValueError("command must not be empty")
        return cleaned


class ExecuteResponse(BaseModel):
    """Response body for POST /execute, e.g. {"success": true, "message": "..."}."""

    success: bool
    message: str


class StatusResponse(BaseModel):
    """Response body for GET /status."""

    status: str
    agent: str
    version: str
    available_commands: int


class CommandsResponse(BaseModel):
    """Response body for GET /commands."""

    commands: Dict[str, str]
    interactive_commands: List[str]


@app.get("/", include_in_schema=False)
def read_root() -> Dict[str, str]:
    """A friendly landing message so visiting the server root isn't a 404."""
    return {
        "message": "Era Agent API is running.",
        "docs": "/docs",
        "status": "/status",
        "commands": "/commands",
    }


@app.get("/status", response_model=StatusResponse)
def get_status() -> StatusResponse:
    """Simple health check so Era can confirm the agent is reachable."""
    return StatusResponse(
        status="online",
        agent="Era Agent for Windows",
        version=app.version,
        available_commands=len(registry.list_commands()),
    )


@app.get("/commands", response_model=CommandsResponse)
def get_commands() -> CommandsResponse:
    """Lists every registered command and its description.

    Also lists which commands are interactive-only (they use input()
    and were built for the CLI), so a caller knows not to send those
    to /execute yet.
    """
    return CommandsResponse(
        commands=registry.list_commands(),
        interactive_commands=sorted(INTERACTIVE_COMMANDS),
    )


@app.post("/execute", response_model=ExecuteResponse)
async def execute_command(request: ExecuteRequest) -> ExecuteResponse:
    """Executes a registered command by name and returns the result.

    This calls the exact same `registry.execute()` used by the
    interactive CLI in main.py, so command behavior is identical
    whether it's triggered from the terminal or from Era over HTTP.
    Unknown commands come back as a normal {"success": false, ...}
    response (the registry already handles this), rather than a raw
    HTTP error, so callers always get a predictable JSON shape.
    """
    command_name = request.command.lower()

    if command_name in INTERACTIVE_COMMANDS:
        return ExecuteResponse(
            success=False,
            message=(
                f"'{command_name}' needs interactive input (e.g. a file name, contact, "
                "or a yes/no confirmation) and isn't supported over the API yet. "
                "Run it from the interactive CLI instead: python main.py"
            ),
        )

    try:
        # Command functions use blocking calls (subprocess, os.startfile),
        # so they run in a thread pool to avoid blocking the server's
        # event loop while a command executes.
        result: CommandResult = await run_in_threadpool(registry.execute, command_name)
    except Exception as exc:  # noqa: BLE001 - always return clean JSON, never a raw 500 trace
        raise HTTPException(status_code=500, detail=f"Unexpected server error: {exc}") from exc

    return ExecuteResponse(success=result.success, message=result.message)
