"""Command registry for Era Agent.

This module provides a lightweight, decorator-based registry so that
new commands can be added in the future without touching the main
application loop in main.py.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, Optional


@dataclass
class CommandResult:
    """Represents the outcome of executing a single command."""

    success: bool
    message: str


CommandFunc = Callable[[], CommandResult]


class CommandRegistry:
    """Holds every available command, keyed by its lowercase name."""

    def __init__(self) -> None:
        self._commands: Dict[str, CommandFunc] = {}
        self._descriptions: Dict[str, str] = {}

    def register(
        self, name: str, description: str = ""
    ) -> Callable[[CommandFunc], CommandFunc]:
        """Decorator used to register a function as a command.

        Example:
            @registry.register("open_notepad", "Opens Notepad")
            def open_notepad() -> CommandResult:
                ...
        """

        def decorator(func: CommandFunc) -> CommandFunc:
            key = name.strip().lower()
            self._commands[key] = func
            self._descriptions[key] = description
            return func

        return decorator

    def get(self, name: str) -> Optional[CommandFunc]:
        return self._commands.get(name.strip().lower())

    def list_commands(self) -> Dict[str, str]:
        """Returns a copy of {command_name: description}."""
        return dict(self._descriptions)

    def execute(self, name: str) -> CommandResult:
        """Runs a command by name and always returns a CommandResult.

        Any unexpected exception raised by a command is caught here so
        the agent never crashes on a single bad command; it is reported
        back as a clean failure message instead.
        """
        func = self.get(name)
        if func is None:
            return CommandResult(False, f"Unknown command: '{name}'")
        try:
            return func()
        except Exception as exc:  # noqa: BLE001 - convert any failure to a clean result
            return CommandResult(False, f"Command '{name}' failed with an error: {exc}")


# A single shared registry instance used across the whole project.
registry = CommandRegistry()
