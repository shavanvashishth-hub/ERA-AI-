"""System-level commands for Era Agent.

Each function below performs exactly one safe, non-destructive action
and returns a CommandResult describing whether it succeeded. None of
these commands request administrator privileges or modify, delete, or
overwrite anything on the system — they only launch existing, standard
Windows applications.
"""

from __future__ import annotations

import platform
import shutil
import subprocess
import time
import webbrowser
from pathlib import Path
from typing import List, Optional
from urllib.parse import quote

from .registry import CommandResult, registry


def _is_windows() -> bool:
    """Returns True if the agent is currently running on Windows."""
    return platform.system().lower() == "windows"


@registry.register("open_notepad", "Opens Windows Notepad")
def open_notepad() -> CommandResult:
    if not _is_windows():
        return CommandResult(False, "Notepad is only available on Windows.")
    try:
        subprocess.Popen(["notepad.exe"])
        return CommandResult(True, "Notepad opened successfully.")
    except FileNotFoundError:
        return CommandResult(False, "Could not find notepad.exe on this system.")
    except OSError as exc:
        return CommandResult(False, f"Failed to open Notepad: {exc}")


@registry.register("open_calculator", "Opens Windows Calculator")
def open_calculator() -> CommandResult:
    if not _is_windows():
        return CommandResult(False, "Calculator is only available on Windows.")
    try:
        subprocess.Popen(["calc.exe"])
        return CommandResult(True, "Calculator opened successfully.")
    except FileNotFoundError:
        return CommandResult(False, "Could not find calc.exe on this system.")
    except OSError as exc:
        return CommandResult(False, f"Failed to open Calculator: {exc}")


@registry.register("open_file_explorer", "Opens Windows File Explorer")
def open_file_explorer() -> CommandResult:
    if not _is_windows():
        return CommandResult(False, "File Explorer is only available on Windows.")
    try:
        subprocess.Popen(["explorer.exe"])
        return CommandResult(True, "File Explorer opened successfully.")
    except FileNotFoundError:
        return CommandResult(False, "Could not find explorer.exe on this system.")
    except OSError as exc:
        return CommandResult(False, f"Failed to open File Explorer: {exc}")


def _find_chrome_path() -> Optional[str]:
    """Looks for Google Chrome on PATH, then in common install locations."""
    which_result = shutil.which("chrome")
    if which_result:
        return which_result

    common_paths = [
        Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
        Path(r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"),
        Path.home() / "AppData" / "Local" / "Google" / "Chrome" / "Application" / "chrome.exe",
    ]
    for path in common_paths:
        if path.exists():
            return str(path)
    return None


@registry.register("open_chrome", "Opens Google Chrome, if installed")
def open_chrome() -> CommandResult:
    if not _is_windows():
        return CommandResult(False, "This Chrome launcher targets Windows only.")

    chrome_path = _find_chrome_path()
    if chrome_path is None:
        return CommandResult(
            False,
            "Google Chrome was not found on this system. "
            "Make sure it is installed in the default location.",
        )

    try:
        subprocess.Popen([chrome_path])
        return CommandResult(True, "Google Chrome opened successfully.")
    except OSError as exc:
        return CommandResult(False, f"Failed to open Google Chrome: {exc}")


# ---------------------------------------------------------------------------
# Additional commands
# ---------------------------------------------------------------------------


@registry.register("search_file", "Searches for a file by name and opens it in File Explorer")
def search_file() -> CommandResult:
    """Searches for a file by name under a chosen root folder.

    Prompts for the file name (or partial name) to look for, and an
    optional root folder to search under (defaults to the user's home
    folder, which is far faster than scanning the entire drive). This
    is a read-only search — nothing is modified.
    """
    if not _is_windows():
        return CommandResult(False, "File Explorer search is only available on Windows.")

    file_name = input("File name (or partial name) to search for: ").strip()
    if not file_name:
        return CommandResult(False, "No file name was provided.")

    root_input = input(
        f"Folder to search under (press Enter for '{Path.home()}'): "
    ).strip()
    search_root = Path(root_input) if root_input else Path.home()

    if not search_root.exists():
        return CommandResult(False, f"Search folder does not exist: {search_root}")

    matches: List[Path] = []
    name_lower = file_name.lower()

    for current_dir, _dirs, files in os.walk(search_root, onerror=lambda err: None):
        for f in files:
            if name_lower in f.lower():
                matches.append(Path(current_dir) / f)
                if len(matches) >= 20:
                    break
        if len(matches) >= 20:
            break

    if not matches:
        return CommandResult(False, f"No file matching '{file_name}' was found under {search_root}.")

    try:
        # Opens File Explorer with the first match highlighted/selected.
        subprocess.Popen(["explorer", f"/select,{matches[0]}"])
    except OSError as exc:
        return CommandResult(False, f"Found the file but could not open File Explorer: {exc}")

    if len(matches) == 1:
        return CommandResult(True, f"Found and opened: {matches[0]}")
    return CommandResult(
        True,
        f"Found {len(matches)} matches. Opened the first one: {matches[0]}",
    )


@registry.register("open_whatsapp", "Opens WhatsApp and sends a message to a contact")
def open_whatsapp() -> CommandResult:
    """Opens WhatsApp (desktop app if installed, otherwise WhatsApp Web)
    with a chat pre-filled for a given phone number and message.

    Uses the official `whatsapp://send` / `web.whatsapp.com/send` URL
    scheme, so no scraping or unofficial API is involved. The message
    is pre-filled in the compose box; you press Enter to actually send
    it, which keeps a human in control of every message that goes out.
    """
    phone = input("Recipient phone number (with country code, e.g. +911234567890): ").strip()
    if not phone:
        return CommandResult(False, "No phone number was provided.")

    message = input("Message to send: ").strip()
    if not message:
        return CommandResult(False, "No message was provided.")

    encoded_message = quote(message)
    # Strip everything except a leading + and digits, as WhatsApp expects.
    clean_phone = "+" + "".join(ch for ch in phone if ch.isdigit()) if phone.strip() else phone

    whatsapp_uri = f"whatsapp://send?phone={clean_phone}&text={encoded_message}"
    web_fallback = f"https://web.whatsapp.com/send?phone={clean_phone}&text={encoded_message}"

    try:
        if _is_windows():
            os.startfile(whatsapp_uri)  # Opens WhatsApp Desktop if installed
        else:
            webbrowser.open(web_fallback)
        return CommandResult(
            True,
            f"WhatsApp opened with your message ready for {clean_phone}. Press Enter in the chat to send it.",
        )
    except OSError:
        # WhatsApp Desktop isn't registered for this URI scheme — fall back to the browser.
        try:
            webbrowser.open(web_fallback)
            return CommandResult(
                True,
                f"Opened WhatsApp Web with your message ready for {clean_phone}. Press Enter in the chat to send it.",
            )
        except Exception as exc:  # noqa: BLE001
            return CommandResult(False, f"Failed to open WhatsApp: {exc}")


@registry.register("shutdown_pc", "Safely shuts down the computer after a short delay")
def shutdown_pc() -> CommandResult:
    """Shuts the computer down safely: asks for confirmation, then gives a
    10-second countdown during which it can be cancelled by running the
    'cancel_shutdown' command. No admin privileges are required for a
    local shutdown of the current machine.
    """
    if not _is_windows():
        return CommandResult(False, "This shutdown command targets Windows only.")

    confirm = input("Type 'yes' to confirm shutdown in 10 seconds: ").strip().lower()
    if confirm != "yes":
        return CommandResult(False, "Shutdown cancelled: confirmation not received.")

    try:
        subprocess.run(["shutdown", "/s", "/t", "10"], check=True)
        return CommandResult(
            True,
            "Shutdown scheduled in 10 seconds. Run 'cancel_shutdown' now to stop it.",
        )
    except (subprocess.CalledProcessError, OSError) as exc:
        return CommandResult(False, f"Failed to schedule shutdown: {exc}")


@registry.register("restart_pc", "Safely restarts the computer after a short delay")
def restart_pc() -> CommandResult:
    """Restarts the computer safely: asks for confirmation, then gives a
    10-second countdown during which it can be cancelled by running the
    'cancel_shutdown' command.
    """
    if not _is_windows():
        return CommandResult(False, "This restart command targets Windows only.")

    confirm = input("Type 'yes' to confirm restart in 10 seconds: ").strip().lower()
    if confirm != "yes":
        return CommandResult(False, "Restart cancelled: confirmation not received.")

    try:
        subprocess.run(["shutdown", "/r", "/t", "10"], check=True)
        return CommandResult(
            True,
            "Restart scheduled in 10 seconds. Run 'cancel_shutdown' now to stop it.",
        )
    except (subprocess.CalledProcessError, OSError) as exc:
        return CommandResult(False, f"Failed to schedule restart: {exc}")


@registry.register("cancel_shutdown", "Cancels a pending shutdown or restart")
def cancel_shutdown() -> CommandResult:
    """Cancels any shutdown/restart scheduled by shutdown_pc or restart_pc."""
    if not _is_windows():
        return CommandResult(False, "This command targets Windows only.")

    try:
        subprocess.run(["shutdown", "/a"], check=True)
        return CommandResult(True, "Pending shutdown/restart was cancelled.")
    except subprocess.CalledProcessError:
        return CommandResult(False, "There was no pending shutdown/restart to cancel.")
    except OSError as exc:
        return CommandResult(False, f"Failed to cancel shutdown: {exc}")


@registry.register("open_camera", "Opens the Windows Camera app")
def open_camera() -> CommandResult:
    """Opens the built-in Windows Camera app via its registered URI."""
    if not _is_windows():
        return CommandResult(False, "Camera launch via this method is only available on Windows.")
    try:
        os.startfile("microsoft.windows.camera:")
        return CommandResult(True, "Camera opened successfully.")
    except OSError as exc:
        return CommandResult(
            False,
            f"Failed to open Camera. Make sure the Windows Camera app is installed: {exc}",
        )


def _find_browser_path(browser_name: str) -> Optional[str]:
    """Looks for a named browser on PATH, then in common install locations."""
    known_paths = {
        "chrome": [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ],
        "edge": [
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        ],
        "firefox": [
            r"C:\Program Files\Mozilla Firefox\firefox.exe",
            r"C:\Program Files (x86)\Mozilla Firefox\firefox.exe",
        ],
        "brave": [
            r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe",
            r"C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application\brave.exe",
        ],
    }

    key = browser_name.strip().lower()
    which_result = shutil.which(key)
    if which_result:
        return which_result

    for path_str in known_paths.get(key, []):
        path = Path(path_str)
        if path.exists():
            return str(path)
    return None


@registry.register("open_browser", "Opens a specified browser (Chrome, Edge, Firefox, Brave)")
def open_browser() -> CommandResult:
    """Opens a browser chosen by name. Falls back to the system default
    browser if the requested one can't be found.
    """
    browser_name = input("Which browser? (chrome / edge / firefox / brave): ").strip()
    if not browser_name:
        return CommandResult(False, "No browser name was provided.")

    browser_path = _find_browser_path(browser_name)
    if browser_path is None:
        try:
            webbrowser.open("https://www.google.com")
            return CommandResult(
                True,
                f"Could not find '{browser_name}', so the system default browser was opened instead.",
            )
        except Exception as exc:  # noqa: BLE001
            return CommandResult(False, f"Failed to open a browser: {exc}")

    try:
        subprocess.Popen([browser_path])
        return CommandResult(True, f"{browser_name.title()} opened successfully.")
    except OSError as exc:
        return CommandResult(False, f"Failed to open {browser_name.title()}: {exc}")


@registry.register("open_app", "Opens any app by name (e.g. spotify, vscode, notepad)")
def open_app() -> CommandResult:
    """Opens an arbitrary application by name or full path.

    Tries, in order:
      1. The name as a command on PATH (e.g. 'code' for VS Code).
      2. os.startfile, which resolves anything Windows already knows
         how to open (registered App Paths, file associations, etc).
      3. The Windows 'start' shell command as a last-resort fallback.
    """
    if not _is_windows():
        return CommandResult(False, "This generic app launcher targets Windows only.")

    app_name = input("App name or full path to open: ").strip()
    if not app_name:
        return CommandResult(False, "No app name was provided.")

    resolved = shutil.which(app_name)
    if resolved:
        try:
            subprocess.Popen([resolved])
            return CommandResult(True, f"'{app_name}' opened successfully.")
        except OSError as exc:
            return CommandResult(False, f"Found '{app_name}' but failed to launch it: {exc}")

    try:
        os.startfile(app_name)
        return CommandResult(True, f"'{app_name}' opened successfully.")
    except OSError:
        pass

    try:
        subprocess.run(["start", "", app_name], shell=True, check=True)
        return CommandResult(True, f"'{app_name}' opened successfully.")
    except (subprocess.CalledProcessError, OSError) as exc:
        return CommandResult(
            False,
            f"Could not find or open '{app_name}'. Make sure it's installed and the name is correct: {exc}",
        )
